/* Simple Mouse Functions for C/C++

General Function
	This freeware is a MS-Mouse library for C/C++.
	It is not a mouse driver !!!

==============================================================================

	Written by FJTC, 1996
	E-Mail address: fjtc@ensino.icmsc.sc.usp.br
	Web address: http://www.geocities.com/SiliconValley/Heights/1378/

==============================================================================

!!! CAUTION !!!

If you want to use this freeware, I assume no responsibility for any effect
that the content of this file can do with your computer.

==============================================================================

Distribute Note:

It is FREE to distribute, but you can not modify or sell this.

==============================================================================

Based on text MS-Mouse by FJTC.
*/
// Compiler security command
#if !defined(__MS_MOUSE_H)
#define __MS_MOUSE_H

// Macros on this file
typedef unsigned char byte;
typedef unsigned int word;

typedef char boolean;
#define TRUE 1
#define FALSE 0

// Mouse Types:
#define NOT_TWO_BUTTONS 0
#define THREE_BUTTONS 3
#define TWO_BUTTONS 2
#define UNKNOW 4
#define NONE 255

// Reset the mouse driver and get status - Call it before others
byte reset_mouse_driver(void);
/* Return: Mouse type ( Use Mouse Type values )*/



// Works only if you have a mouse driver installed
// Show mouse cursor
void show_mouse_cursor(void);

// Works only if you have a mouse driver installed
// Hide mouse cursor
void hide_mouse_cursor(void);

// Works only if you have a mouse driver installed
// Get Mouse Status
void mouse_status(word *x, word *y, boolean *lbutton, boolean *rbutton, boolean *mbutton);


// Implementation


// Reset the mouse driver and get status - Call it before others
byte reset_mouse_driver(void){
	// Local Variables
	word mouse_type; // will store the mouse type
	word driver_status; // will store the mouse driver status
	byte return_value; // will store the function return value

	// Call the driver function 0x0000
	asm{
		mov ax, 0x0000
		int 0x33
		mov driver_status, ax
		mov mouse_type, bx
	}//End Asm

	if (driver_status==0xFFFF) /*then*/{
		// Driver enabled
		// Number of buttons
		switch (mouse_type) {
			case 0x0000:// other than two
				return_value = NOT_TWO_BUTTONS;
				break;
			case 0x0002:// two buttons
				return_value = TWO_BUTTONS;
				break;
			case 0x0003:// Three buttons
				return_value = THREE_BUTTONS;
				break;
			case 0xFFFF:// Unknow mouse type
				return_value = UNKNOW;
				break;
		}//End Swicth
	}else{
		// No mouse driver detected
		return_value = NONE;
	}//End If
	return return_value;
}//End Function

// Works only if you have a mouse driver installed
// Show mouse cursor
void show_mouse_cursor(void){
	// Call driver function 0x0001
	asm{
		mov ax, 0x0001

		int 0x33
	}//End Asm
}//End Function

// Works only if you have a mouse driver installed
// Hide mouse cursor
void hide_mouse_cursor(void){
	// Call driver function 0x0002
	asm{
		mov ax, 0x0002

		int 0x33
	}//End Asm
}//End Function

// Works only if you have a mouse driver installed
// Get Mouse Status
void mouse_status(word *x, word *y, boolean *lbutton, boolean *rbutton, boolean *mbutton){
	// Local Variables
	word button_status;
	word x_status;
	word y_status;

	asm{
		mov ax, 0x0003

		int 0x33

		mov button_status, bx
		mov x_status, cx
		mov y_status, dx
	}//End Asm
	*x = x_status;
	*y = y_status;
	if ((button_status&0x0001) == 1)/*then*/{
		*lbutton = TRUE;
	}else{
		*lbutton = FALSE;
	}//End If
	if ((button_status&0x0002) == 2)/*then*/{
		*rbutton = TRUE;
	}else{
		*rbutton = FALSE;
	}//End If
	if ((button_status&0x0004) == 4)/*then*/{
		*mbutton = TRUE;
	}else{
		*mbutton = FALSE;
	}//End If
}//End Function

#endif